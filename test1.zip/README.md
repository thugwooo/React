# singlepage-responsive-web
A simple responsive web practice example 
